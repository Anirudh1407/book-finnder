-- MySQL dump 10.13  Distrib 8.0.19, for Linux (x86_64)
--
-- Host: localhost    Database: BOOKFINDER
-- ------------------------------------------------------
-- Server version	8.0.19-0ubuntu0.19.10.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
INSERT INTO `auth_group` VALUES (2,'Admin'),(1,'User');
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
INSERT INTO `auth_group_permissions` VALUES (1,2,13),(2,2,14),(3,2,15),(4,2,16),(5,2,25),(6,2,28),(7,2,29),(8,2,30),(9,2,31),(10,2,32),(11,2,33),(12,2,34),(13,2,35),(14,2,36),(15,2,37),(16,2,38),(17,2,39),(18,2,40),(19,2,41),(20,2,42),(21,2,43),(22,2,44),(23,2,45),(24,2,46),(25,2,47),(26,2,48),(27,2,49),(28,2,50),(29,2,51),(30,2,52),(31,2,53),(32,2,54),(33,2,55),(34,2,56);
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add admin profile',7,'add_adminprofile'),(26,'Can change admin profile',7,'change_adminprofile'),(27,'Can delete admin profile',7,'delete_adminprofile'),(28,'Can view admin profile',7,'view_adminprofile'),(29,'Can add admin',8,'add_admin'),(30,'Can change admin',8,'change_admin'),(31,'Can delete admin',8,'delete_admin'),(32,'Can view admin',8,'view_admin'),(33,'Can add user',9,'add_user'),(34,'Can change user',9,'change_user'),(35,'Can delete user',9,'delete_user'),(36,'Can view user',9,'view_user'),(37,'Can add user profile',10,'add_userprofile'),(38,'Can change user profile',10,'change_userprofile'),(39,'Can delete user profile',10,'delete_userprofile'),(40,'Can view user profile',10,'view_userprofile'),(41,'Can add author',11,'add_author'),(42,'Can change author',11,'change_author'),(43,'Can delete author',11,'delete_author'),(44,'Can view author',11,'view_author'),(45,'Can add tag',12,'add_tag'),(46,'Can change tag',12,'change_tag'),(47,'Can delete tag',12,'delete_tag'),(48,'Can view tag',12,'view_tag'),(49,'Can add book',13,'add_book'),(50,'Can change book',13,'change_book'),(51,'Can delete book',13,'delete_book'),(52,'Can view book',13,'view_book'),(53,'Can add issue',14,'add_issue'),(54,'Can change issue',14,'change_issue'),(55,'Can delete issue',14,'delete_issue'),(56,'Can view issue',14,'view_issue'),(57,'Can add user profile',15,'add_userprofile'),(58,'Can change user profile',15,'change_userprofile'),(59,'Can delete user profile',15,'delete_userprofile'),(60,'Can view user profile',15,'view_userprofile'),(61,'Can add admin profile',16,'add_adminprofile'),(62,'Can change admin profile',16,'change_adminprofile'),(63,'Can delete admin profile',16,'delete_adminprofile'),(64,'Can view admin profile',16,'view_adminprofile'),(65,'Can add admin request',17,'add_adminrequest'),(66,'Can change admin request',17,'change_adminrequest'),(67,'Can delete admin request',17,'delete_adminrequest'),(68,'Can view admin request',17,'view_adminrequest'),(69,'Can add admin parent',18,'add_adminparent'),(70,'Can change admin parent',18,'change_adminparent'),(71,'Can delete admin parent',18,'delete_adminparent'),(72,'Can view admin parent',18,'view_adminparent');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$180000$O9sKVvN90wTu$wR5+AsZT1FzSt+hCkNL18iLrJ0YaxMuk8qJFg4RXwKI=','2020-03-03 16:14:04.954398',1,'root','','','someone@somemail.com',1,1,'2020-03-02 10:11:59.180828'),(2,'pbkdf2_sha256$180000$3YGa7qI2Cy5t$uQPQt6g0UF+675NqXwXQRpkGFf+VVn6jQ0G75Md7A3w=',NULL,0,'John','','','',0,1,'2020-03-02 10:34:28.133881'),(3,'pbkdf2_sha256$180000$4m7YNmPsoKsF$HMLIOH4UIfj+JHovdlI2BYCp1eP8E96sKf25j1OEnyA=',NULL,0,'Prahalad','','','',0,1,'2020-03-02 11:33:49.836977'),(4,'pbkdf2_sha256$180000$s4YFYWl2f9Pe$EcX60pGPXMV4ssOoD7NuHXqJl73HWKuR2UG1hLEw7Og=',NULL,0,'Anirudh','','','',0,1,'2020-03-02 11:34:03.643474'),(5,'pbkdf2_sha256$180000$NUvWtvJCRel0$eEdpJoUEFsg4zUfi+op2GJIBLf8PzZT+1sJ5DI5Fjsk=',NULL,0,'Ram','','','',0,1,'2020-03-02 11:34:23.482203'),(6,'pbkdf2_sha256$180000$ZKqvtZl2DUQ0$TVayYSp0kiMmRsG8oSc4cblRTb9+OiUI/OxWaIBhtOQ=',NULL,0,'Shyam','','','',0,1,'2020-03-02 11:34:35.965718'),(7,'pbkdf2_sha256$180000$kdYSuJdRXqIA$VjoQBEChIfeTZF1iQ1Lp/xM13zyRBu0/8KyWWqBMKQA=',NULL,0,'Suppandi','','','',0,1,'2020-03-02 11:36:20.039877'),(9,'pbkdf2_sha256$180000$uT9LhsXZz7ln$4IvaRtfhyWiEMPsG/Oh30+ZAnRxZF9deSurrW2t1l8E=',NULL,0,'Raju','','','',0,1,'2020-03-02 11:37:56.064207'),(10,'pbkdf2_sha256$180000$iLtYHlqrnfks$84v/ZxcnhlLD/Kfph+czpo1j0q9RajTEkEhh2OBUCYo=',NULL,0,'jklsadfjkdfals','','','',0,1,'2020-03-03 16:42:36.861462'),(11,'pbkdf2_sha256$180000$NcarNSLZoncN$NRC0VkwAA4ljP351bpTKGyiJbPIHaymHYUz7rJ2ctFA=',NULL,0,'afds','','','',0,1,'2020-03-04 16:08:06.141344'),(12,'pbkdf2_sha256$180000$mq8oIlJgtnBF$UV164qmAp+BkLgCWSJjsC4gd4jKrcls/5woBryBQvtE=',NULL,0,'afdsg','','','',0,1,'2020-03-04 16:20:05.294486'),(13,'pbkdf2_sha256$180000$Fwcv8t8uAyhk$JwCNylGqpXfS0yXSYto2s6Yzz6wqPWt8GZm7AOQyNtI=',NULL,0,'afdsgh','','','',0,1,'2020-03-04 16:22:04.873085'),(14,'pbkdf2_sha256$180000$TcXfT0HOQRnB$HXEUlAENUpeGznxOHWIPl2cjef0ygDTt2DRQrM/+Zkg=',NULL,0,'afdsghi','','','',0,1,'2020-03-04 16:24:38.357541'),(15,'pbkdf2_sha256$180000$iKlPXG2etxB0$1jEUne4uKvSIT6p5PMhUyGzy1naMmbrLKCAGKoe+Gs4=',NULL,0,'aafdsghi','','','',0,1,'2020-03-04 16:25:15.077390'),(16,'pbkdf2_sha256$180000$jo7g723dgHvc$xhrTBwbKDQFzbWj+Frn7lYRqOjUjQICLYtBY1rLohjE=',NULL,0,'aafdsghif','','','',0,1,'2020-03-04 16:25:44.359958'),(17,'pbkdf2_sha256$180000$rlYes7btsfKt$Wn8Ro9VVkPkPIlyeSJrpB3JAxycTbRfaOtVQ5UjpZN4=',NULL,0,'aafdsghifg','','','',0,1,'2020-03-04 16:27:33.029503'),(18,'pbkdf2_sha256$180000$6m4WvqCzcV2Y$Q6lve0qzpSK190IigsNQGifsospPY3Jlt0UaBLWK1Ns=',NULL,0,'alskdfjalksdfj','','','',0,1,'2020-03-04 17:44:32.871310'),(19,'pbkdf2_sha256$180000$eiF6JmvLT7WN$4IBkZRNfEXKSjCREvsrMNlsS8eku9M1lamzmXK8lkpY=',NULL,0,'alskdfjalksdfjg','','','',0,1,'2020-03-04 17:55:46.790275'),(20,'pbkdf2_sha256$180000$2VoR3VwtLoRJ$vMvG5EV0CsZpaIvJqiWlBQls/me6TgSUFOlfxlmayYI=',NULL,0,'pleasework','','','',0,1,'2020-03-04 17:56:31.691501'),(21,'pbkdf2_sha256$180000$XoXHurLQOkY9$/aN1sefCTBnMB5x5JjEOQrepW4mLj4Uy8acLRzt3qP4=',NULL,0,'pleaseworknow','','','',0,1,'2020-03-04 17:58:51.246385'),(22,'pbkdf2_sha256$180000$q0ULuvg2lvru$ofvqCrM84cT/laFrYwryaNGmsurrrVfLqrf9sAD/HDI=',NULL,0,'nowatleast','','','',0,1,'2020-03-04 18:03:33.065184'),(24,'pbkdf2_sha256$180000$0vFj0xQnYE9l$lMUV9yWfUAJgrv+Z3Ej9EdBettdAYmUcewb5RNS5FgU=','2020-03-10 04:46:27.066552',0,'workagain1','','','',0,1,'2020-03-04 18:24:45.000000'),(25,'pbkdf2_sha256$180000$LJlqDik1QoxP$mYLbhInLADE/Ul4VFGJ9O1UdMSMRViEYswdNuqdzuHo=','2020-03-09 06:36:21.199634',0,'workagain2','','','',0,1,'2020-03-04 18:27:06.543532'),(26,'pbkdf2_sha256$180000$VycrXvrJwzyK$OSdO6jMKl3FQtXhCiASIwkRd9aqXnQZHX73K49ZVThk=','2020-03-07 09:22:30.912247',0,'workagain3','','','',0,1,'2020-03-04 18:27:48.721176'),(27,'pbkdf2_sha256$180000$syoOouSzsRjw$yKk+GRA269/hOmGPzNJrNrs3GbHZf0K9s6wuWv4Yd0M=','2020-03-09 06:31:36.493114',0,'workagain4','','','',0,1,'2020-03-04 18:32:09.814070'),(28,'pbkdf2_sha256$180000$rvKkET85lxh0$uozIZ62RTN0Z0e+7USh0C5Ui8QqZG72Uf9gyeGYYiD4=','2020-03-09 06:34:12.631222',0,'workagain5','','','',0,1,'2020-03-04 18:38:54.942928'),(29,'pbkdf2_sha256$180000$QdITMpHq44Gh$PPl23YmcIxMPymTeIJwW9aRRkjVlRlHm4B7YKZwcVCA=',NULL,0,'thiswillwork','','','',0,1,'2020-03-04 18:39:46.681554'),(30,'pbkdf2_sha256$180000$f4qTxCQsmGXw$dJIc9T/WOnRjUTX5qZPJt5NsrRddVGPt60u/bK2j47Q=',NULL,0,'thiswillworkhope','','','',0,1,'2020-03-04 18:40:25.614068'),(31,'pbkdf2_sha256$180000$yQSKvjcvUQIj$dYY/DMxzal7ey/38NluaBX6yUpRPzZdxJUQfCwzif/U=',NULL,0,'thiswillworkhopefully','','','',0,1,'2020-03-04 18:43:29.122615'),(32,'pbkdf2_sha256$180000$kOB1HlqY3bfM$sv70uSQphJ5p+0MfuqygpodYSPIUEHJM2ip9bFF43RQ=','2020-03-04 18:44:34.767889',0,'thiswillworkhopeful','','','',0,1,'2020-03-04 18:44:33.968421'),(33,'pbkdf2_sha256$180000$aEMU3jZPQAHh$GFqbOuuuxMY0xgECBoNLq8ozr87Mn7rwfeAYXLYBxY4=','2020-03-04 18:45:50.615229',0,'pleaseworkthen','','','',0,1,'2020-03-04 18:45:49.737642'),(34,'pbkdf2_sha256$180000$FmvYYBnp73jx$DqVuJ/5pWq9FrARB5MCipROlFWcOTNkmqWR4+E2cLdQ=','2020-03-04 18:51:37.231656',0,'testcase1','','','',0,1,'2020-03-04 18:51:36.268228'),(35,'pbkdf2_sha256$180000$x6i4MISlqH2i$OI2nQWaAzVvIKVuc5n42Tr3iXv5WCrjvxKiUMk2mut8=','2020-03-06 06:54:50.623075',0,'Helloworld','','','',0,1,'2020-03-06 06:54:49.960686'),(38,'pbkdf2_sha256$180000$ISryVp6RUrpP$N1tRNiRu7DdHL/nxLQKQ5LYNpUuMe6v6NwASBuDgGKo=','2020-03-09 06:32:45.865114',1,'superuser','','','superuser@mail.com',1,1,'2020-03-06 09:25:55.533155');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
INSERT INTO `auth_user_groups` VALUES (6,24,2),(7,25,2);
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books_author`
--

DROP TABLE IF EXISTS `books_author`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books_author` (
  `id` int NOT NULL AUTO_INCREMENT,
  `author` varchar(20) NOT NULL,
  `book_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `books_author_book_id_607064dd_fk_books_book_book` (`book_id`),
  CONSTRAINT `books_author_book_id_607064dd_fk_books_book_book` FOREIGN KEY (`book_id`) REFERENCES `books_book` (`book`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books_author`
--

LOCK TABLES `books_author` WRITE;
/*!40000 ALTER TABLE `books_author` DISABLE KEYS */;
INSERT INTO `books_author` VALUES (1,'Larry Page',1),(2,'Sergey Brin',1),(3,'Mark Zuckerberg',2),(4,'John Grisham',5),(5,'Dan Brown',6),(6,'Wilkie Colins',7),(7,'Marc Behm',8),(8,'Thomas Berger',9),(9,'Scott B. Smith',10);
/*!40000 ALTER TABLE `books_author` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books_book`
--

DROP TABLE IF EXISTS `books_book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books_book` (
  `book` int NOT NULL AUTO_INCREMENT,
  `edition` int NOT NULL,
  `added_by_id` int NOT NULL,
  `link` varchar(200) NOT NULL,
  `name` longtext NOT NULL,
  PRIMARY KEY (`book`),
  KEY `books_book_added_by_id_cf55bf7a` (`added_by_id`),
  CONSTRAINT `books_book_added_by_id_cf55bf7a_fk_auth_user_id` FOREIGN KEY (`added_by_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books_book`
--

LOCK TABLES `books_book` WRITE;
/*!40000 ALTER TABLE `books_book` DISABLE KEYS */;
INSERT INTO `books_book` VALUES (1,1,1,'www.google.com','google book'),(2,1,1,'www.facebook.com','face book'),(3,1,9,'Broken Link','No name'),(4,1,6,'www.gmail.com','mail book'),(5,1,3,'thewhistler.com','The whistler'),(6,1,4,'danbrownbooks.com','Da Vinci Code'),(7,1,9,'mysterybooks.com','The Woman in White'),(8,1,7,'famousbooks.com','The Eye of the Beholder'),(9,1,3,'bergerbooks.com','Sneaky People'),(10,1,4,'Broken Link','A Simple Plan');
/*!40000 ALTER TABLE `books_book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books_issue`
--

DROP TABLE IF EXISTS `books_issue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books_issue` (
  `issue` int NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL,
  `description` varchar(200) NOT NULL,
  `assigned_to_id` int NOT NULL,
  `added_by_id` int NOT NULL,
  `book_id` int NOT NULL,
  PRIMARY KEY (`issue`),
  KEY `books_issue_added_by_id_f7eb1412_fk_auth_user_id` (`added_by_id`),
  KEY `books_issue_book_id_4076eabf_fk_books_book_book` (`book_id`),
  KEY `books_issue_assigned_to_id_74ba0548` (`assigned_to_id`),
  CONSTRAINT `books_issue_added_by_id_f7eb1412_fk_auth_user_id` FOREIGN KEY (`added_by_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `books_issue_assigned_to_id_74ba0548_fk_auth_user_id` FOREIGN KEY (`assigned_to_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `books_issue_book_id_4076eabf_fk_books_book_book` FOREIGN KEY (`book_id`) REFERENCES `books_book` (`book`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books_issue`
--

LOCK TABLES `books_issue` WRITE;
/*!40000 ALTER TABLE `books_issue` DISABLE KEYS */;
INSERT INTO `books_issue` VALUES (1,'unresolved','No issue reported',24,12,2),(4,'unresolved','This is isnt a book',24,24,1);
/*!40000 ALTER TABLE `books_issue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books_tag`
--

DROP TABLE IF EXISTS `books_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books_tag` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tag` varchar(20) NOT NULL,
  `book_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `books_tag_book_id_d0c733b9_fk_books_book_book` (`book_id`),
  CONSTRAINT `books_tag_book_id_d0c733b9_fk_books_book_book` FOREIGN KEY (`book_id`) REFERENCES `books_book` (`book`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books_tag`
--

LOCK TABLES `books_tag` WRITE;
/*!40000 ALTER TABLE `books_tag` DISABLE KEYS */;
INSERT INTO `books_tag` VALUES (2,'Programming',1),(3,'Useless',2),(4,'Communication',4),(5,'Communication',1),(6,'Mystery',5),(7,'Mystery',6),(8,'Mystery',7),(9,'Horror',7),(10,'Thriller',7),(11,'Mystery',8),(12,'Mystery',9),(13,'Thriller',9),(14,'Mystery',10),(15,'Classic',10);
/*!40000 ALTER TABLE `books_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2020-03-02 10:34:28.466163','2','John',1,'[{\"added\": {}}]',4,1),(2,'2020-03-02 11:33:50.162613','3','Prahalad',1,'[{\"added\": {}}]',4,1),(3,'2020-03-02 11:34:04.022374','4','Anirudh',1,'[{\"added\": {}}]',4,1),(4,'2020-03-02 11:34:23.858599','5','Ram',1,'[{\"added\": {}}]',4,1),(5,'2020-03-02 11:34:36.277558','6','Shyam',1,'[{\"added\": {}}]',4,1),(6,'2020-03-02 11:36:20.487962','7','Suppandi',1,'[{\"added\": {}}]',4,1),(7,'2020-03-02 11:36:53.646728','8','Kalia',1,'[{\"added\": {}}]',4,1),(8,'2020-03-02 11:37:56.321220','9','Raju',1,'[{\"added\": {}}]',4,1),(9,'2020-03-02 11:42:40.116777','1','User',1,'[{\"added\": {}}]',3,1),(10,'2020-03-02 11:45:02.606339','2','Admin',1,'[{\"added\": {}}]',3,1),(11,'2020-03-02 11:50:48.051680','4','Anirudh',1,'[{\"added\": {}}]',7,1),(12,'2020-03-02 11:51:11.401126','3','Prahalad',1,'[{\"added\": {}}]',7,1),(13,'2020-03-02 11:52:03.515536','1','root',1,'[{\"added\": {}}]',7,1),(14,'2020-03-02 12:07:17.146910','1','google book',1,'[{\"added\": {}}]',13,1),(15,'2020-03-02 12:07:35.031622','2','face book',1,'[{\"added\": {}}]',13,1),(16,'2020-03-02 12:08:27.955700','3','No name',1,'[{\"added\": {}}]',13,1),(17,'2020-03-02 12:08:47.925534','4','mail book',1,'[{\"added\": {}}]',13,1),(18,'2020-03-02 12:09:17.544061','1','Larry Page',1,'[{\"added\": {}}]',11,1),(19,'2020-03-02 12:09:24.293896','2','Sergey Brin',1,'[{\"added\": {}}]',11,1),(20,'2020-03-02 12:09:44.946948','3','Mark Zuckerberg',1,'[{\"added\": {}}]',11,1),(21,'2020-03-02 12:14:11.145611','1','Broken Link',1,'[{\"added\": {}}]',14,1),(22,'2020-03-02 12:14:24.887375','2','Broken Link',1,'[{\"added\": {}}]',14,1),(23,'2020-03-02 12:15:30.842806','3','No specific issue reported',1,'[{\"added\": {}}]',14,1),(24,'2020-03-02 12:15:58.764636','2','Programming',1,'[{\"added\": {}}]',12,1),(25,'2020-03-02 12:16:07.759592','3','Useless',1,'[{\"added\": {}}]',12,1),(26,'2020-03-02 12:16:16.368979','4','Communication',1,'[{\"added\": {}}]',12,1),(27,'2020-03-02 12:16:29.258345','5','Communication',1,'[{\"added\": {}}]',12,1),(28,'2020-03-02 12:17:14.367445','6','Shyam',1,'[{\"added\": {}}]',10,1),(29,'2020-03-02 12:17:36.189221','8','Kalia',1,'[{\"added\": {}}]',10,1),(30,'2020-03-02 17:51:57.845698','8','Kalia',1,'[{\"added\": {}}]',15,1),(31,'2020-03-02 18:28:35.764588','5','The whistler',1,'[{\"added\": {}}]',13,1),(32,'2020-03-02 18:29:04.912219','6','Da Vinci Code',1,'[{\"added\": {}}]',13,1),(33,'2020-03-02 18:29:28.307775','7','The Woman in White',1,'[{\"added\": {}}]',13,1),(34,'2020-03-02 18:29:53.165286','8','The Eye of the Beholder',1,'[{\"added\": {}}]',13,1),(35,'2020-03-02 18:30:29.130766','9','Sneaky People',1,'[{\"added\": {}}]',13,1),(36,'2020-03-02 18:30:45.111307','10','A Simple Plan',1,'[{\"added\": {}}]',13,1),(37,'2020-03-02 18:31:11.521224','4','John Grisham',1,'[{\"added\": {}}]',11,1),(38,'2020-03-02 18:31:27.268680','5','Dan Brown',1,'[{\"added\": {}}]',11,1),(39,'2020-03-02 18:31:43.381926','6','Wilkie Colins',1,'[{\"added\": {}}]',11,1),(40,'2020-03-02 18:31:53.488388','7','Marc Behm',1,'[{\"added\": {}}]',11,1),(41,'2020-03-02 18:32:03.803976','8','Thomas Berger',1,'[{\"added\": {}}]',11,1),(42,'2020-03-02 18:32:14.134061','9','Scott B. Smith',1,'[{\"added\": {}}]',11,1),(43,'2020-03-02 18:33:02.861932','4','Book is different',1,'[{\"added\": {}}]',14,1),(44,'2020-03-02 18:33:20.683653','5','Edition is wrong',1,'[{\"added\": {}}]',14,1),(45,'2020-03-02 18:33:40.644085','6','Full book not available',1,'[{\"added\": {}}]',14,1),(46,'2020-03-02 18:33:56.303250','7','Link does not exist',1,'[{\"added\": {}}]',14,1),(47,'2020-03-02 18:34:16.350263','8','Violates copyrights',1,'[{\"added\": {}}]',14,1),(48,'2020-03-02 18:34:37.204921','9','Book details too vague',1,'[{\"added\": {}}]',14,1),(49,'2020-03-02 18:35:00.930756','6','Mystery',1,'[{\"added\": {}}]',12,1),(50,'2020-03-02 18:35:06.908835','7','Mystery',1,'[{\"added\": {}}]',12,1),(51,'2020-03-02 18:35:13.611537','8','Mystery',1,'[{\"added\": {}}]',12,1),(52,'2020-03-02 18:35:19.045844','9','Horror',1,'[{\"added\": {}}]',12,1),(53,'2020-03-02 18:35:25.934123','10','Thriller',1,'[{\"added\": {}}]',12,1),(54,'2020-03-02 18:35:36.426637','11','Mystery',1,'[{\"added\": {}}]',12,1),(55,'2020-03-02 18:35:44.313989','12','Mystery',1,'[{\"added\": {}}]',12,1),(56,'2020-03-02 18:35:51.196203','13','Thriller',1,'[{\"added\": {}}]',12,1),(57,'2020-03-02 18:35:57.440386','14','Mystery',1,'[{\"added\": {}}]',12,1),(58,'2020-03-02 18:36:04.353274','15','Classic',1,'[{\"added\": {}}]',12,1),(59,'2020-03-06 09:26:34.558124','11','bheem',1,'[{\"added\": {}}]',13,38),(60,'2020-03-06 18:40:43.899868','2','Admin',2,'[{\"changed\": {\"fields\": [\"Permissions\"]}}]',3,38),(61,'2020-03-06 18:41:21.771328','37','Bholu',2,'[{\"changed\": {\"fields\": [\"Groups\"]}}]',4,38),(62,'2020-03-07 04:52:00.506108','37','Bholu',3,'',4,38),(63,'2020-03-07 04:52:00.520154','36','Dholu',3,'',4,38),(64,'2020-03-07 04:52:00.532189','39','MightyRaju',3,'',4,38),(65,'2020-03-07 05:00:01.552164','1','root',1,'[{\"added\": {}}]',15,38),(66,'2020-03-07 05:03:51.118139','23','workagain',3,'',4,38),(67,'2020-03-07 05:07:22.579539','24','workagain1',2,'[{\"changed\": {\"fields\": [\"Groups\"]}}]',4,38),(68,'2020-03-07 07:51:43.393311','1','No issue reported',1,'[{\"added\": {}}]',14,38);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(8,'books','admin'),(7,'books','adminprofile'),(11,'books','author'),(13,'books','book'),(14,'books','issue'),(12,'books','tag'),(9,'books','user'),(10,'books','userprofile'),(5,'contenttypes','contenttype'),(6,'sessions','session'),(18,'users','adminparent'),(16,'users','adminprofile'),(17,'users','adminrequest'),(15,'users','userprofile');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2020-03-01 13:38:55.649372'),(2,'auth','0001_initial','2020-03-01 13:38:56.546214'),(3,'admin','0001_initial','2020-03-01 13:38:58.854386'),(4,'admin','0002_logentry_remove_auto_add','2020-03-01 13:38:59.439073'),(5,'admin','0003_logentry_add_action_flag_choices','2020-03-01 13:38:59.489584'),(6,'contenttypes','0002_remove_content_type_name','2020-03-01 13:38:59.911104'),(7,'auth','0002_alter_permission_name_max_length','2020-03-01 13:39:00.229604'),(8,'auth','0003_alter_user_email_max_length','2020-03-01 13:39:00.359431'),(9,'auth','0004_alter_user_username_opts','2020-03-01 13:39:00.382754'),(10,'auth','0005_alter_user_last_login_null','2020-03-01 13:39:00.639034'),(11,'auth','0006_require_contenttypes_0002','2020-03-01 13:39:00.652816'),(12,'auth','0007_alter_validators_add_error_messages','2020-03-01 13:39:00.675227'),(13,'auth','0008_alter_user_username_max_length','2020-03-01 13:39:00.916648'),(14,'auth','0009_alter_user_last_name_max_length','2020-03-01 13:39:01.178167'),(15,'auth','0010_alter_group_name_max_length','2020-03-01 13:39:01.270012'),(16,'auth','0011_update_proxy_permissions','2020-03-01 13:39:01.304983'),(17,'sessions','0001_initial','2020-03-01 13:39:01.403196'),(18,'books','0001_initial','2020-03-02 10:06:59.924400'),(19,'books','0002_auto_20200302_1126','2020-03-02 11:27:12.895378'),(20,'books','0003_adminprofile_author_book_issue_tag_userprofile','2020-03-02 11:27:38.210880'),(21,'books','0004_auto_20200302_1155','2020-03-02 11:56:06.055906'),(22,'books','0005_auto_20200302_1206','2020-03-02 12:06:41.480578'),(23,'books','0006_auto_20200302_1213','2020-03-02 12:14:01.385043'),(24,'books','0007_auto_20200302_1215','2020-03-02 12:15:25.517296'),(25,'books','0008_auto_20200302_1728','2020-03-02 17:31:31.672985'),(26,'users','0001_initial','2020-03-02 17:31:31.922964'),(27,'users','0002_adminrequest','2020-03-06 18:36:09.840035'),(28,'users','0003_adminparent','2020-03-07 04:50:37.937884'),(29,'books','0009_issue_assigned_to','2020-03-07 06:07:58.089159'),(30,'books','0010_delete_issue','2020-03-07 06:09:00.386829'),(31,'books','0011_issue','2020-03-07 06:09:40.615350'),(32,'books','0012_auto_20200307_0610','2020-03-07 06:10:37.451162'),(33,'books','0013_auto_20200307_0929','2020-03-07 09:29:31.369429');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('ts0g3ff17y3bauodxlysoqmqjv1pgb8r','ZTAxZjE5Nzc4NDBjNWJlMDUxZmM4YjQ0ZTRhNTE4YTc2Y2M4YjZkZTp7Il9hdXRoX3VzZXJfaWQiOiIyNCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiOWI1YWU4YWZkMzMzMjJhNTVmZTRkZjU4YzM4ZTZlODI3NWYzNzc0NiJ9','2020-03-24 04:46:27.100947');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_adminparent`
--

DROP TABLE IF EXISTS `users_adminparent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_adminparent` (
  `created_id` int NOT NULL,
  `creator_id` int NOT NULL,
  PRIMARY KEY (`created_id`),
  KEY `users_adminparent_creator_id_2adba1e2_fk_auth_user_id` (`creator_id`),
  CONSTRAINT `users_adminparent_created_id_b9df842f_fk_auth_user_id` FOREIGN KEY (`created_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `users_adminparent_creator_id_2adba1e2_fk_auth_user_id` FOREIGN KEY (`creator_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_adminparent`
--

LOCK TABLES `users_adminparent` WRITE;
/*!40000 ALTER TABLE `users_adminparent` DISABLE KEYS */;
INSERT INTO `users_adminparent` VALUES (24,24),(25,24);
/*!40000 ALTER TABLE `users_adminparent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_adminprofile`
--

DROP TABLE IF EXISTS `users_adminprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_adminprofile` (
  `admin_id` int NOT NULL,
  `creation_date` datetime(6) NOT NULL,
  `name` varchar(20) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `dob` datetime(6) NOT NULL,
  `issues_left` int NOT NULL,
  `tag` varchar(20) NOT NULL,
  `country` varchar(20) NOT NULL,
  PRIMARY KEY (`admin_id`),
  CONSTRAINT `users_adminprofile_admin_id_7897a325_fk_auth_user_id` FOREIGN KEY (`admin_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_adminprofile`
--

LOCK TABLES `users_adminprofile` WRITE;
/*!40000 ALTER TABLE `users_adminprofile` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_adminprofile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_adminrequest`
--

DROP TABLE IF EXISTS `users_adminrequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_adminrequest` (
  `user_id` int NOT NULL,
  `assigned_to_id` int NOT NULL,
  PRIMARY KEY (`user_id`),
  KEY `users_adminrequest_assigned_to_id_c023785a_fk_auth_user_id` (`assigned_to_id`),
  CONSTRAINT `users_adminrequest_assigned_to_id_c023785a_fk_auth_user_id` FOREIGN KEY (`assigned_to_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `users_adminrequest_user_id_8aeddb37_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_adminrequest`
--

LOCK TABLES `users_adminrequest` WRITE;
/*!40000 ALTER TABLE `users_adminrequest` DISABLE KEYS */;
INSERT INTO `users_adminrequest` VALUES (28,25);
/*!40000 ALTER TABLE `users_adminrequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_userprofile`
--

DROP TABLE IF EXISTS `users_userprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_userprofile` (
  `user_id` int NOT NULL,
  `creation_date` datetime(6) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `name` varchar(20) NOT NULL,
  `dob` datetime(6) NOT NULL,
  `country` varchar(20) NOT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `users_userprofile_user_id_87251ef1_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_userprofile`
--

LOCK TABLES `users_userprofile` WRITE;
/*!40000 ALTER TABLE `users_userprofile` DISABLE KEYS */;
INSERT INTO `users_userprofile` VALUES (1,'2020-03-07 04:59:41.000000','M','root','2020-03-07 04:59:48.000000','India'),(21,'2020-03-04 00:00:00.000000','M','hello','2004-02-03 00:00:00.000000','India'),(22,'2020-03-04 00:00:00.000000','M','somebody','2004-02-03 00:00:00.000000','India'),(24,'2020-03-04 00:00:00.000000','M','someothername','2004-02-03 00:00:00.000000','India'),(25,'2020-03-04 00:00:00.000000','M','workingname','2004-02-03 00:00:00.000000','India'),(26,'2020-03-04 00:00:00.000000','M','notworkingname','2004-02-03 00:00:00.000000','India'),(27,'2020-03-04 00:00:00.000000','M','notworkingname','2004-02-03 00:00:00.000000','India'),(28,'2020-03-04 00:00:00.000000','M','notworkingnameagain','2004-02-03 00:00:00.000000','India'),(29,'2020-03-04 00:00:00.000000','M','pleaseworkpa','2004-02-03 00:00:00.000000','India'),(30,'2020-03-04 00:00:00.000000','M','pleaseworkpls','2004-02-03 00:00:00.000000','India'),(31,'2020-03-04 00:00:00.000000','M','pleaseworkpls','2004-02-03 00:00:00.000000','India'),(32,'2020-03-04 00:00:00.000000','M','pleaseworkpls','2004-02-03 00:00:00.000000','India'),(33,'2020-03-04 00:00:00.000000','M','soemname','2004-02-03 00:00:00.000000','India'),(34,'2020-03-04 00:00:00.000000','M','plswork','2004-02-03 00:00:00.000000','India'),(35,'2020-03-06 00:00:00.000000','M','hithere','2004-02-03 00:00:00.000000','India');
/*!40000 ALTER TABLE `users_userprofile` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-10  1:03:08
