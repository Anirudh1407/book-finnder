from django.contrib import admin
from django.apps import apps
# Register your models here.

admin.site.site_header = "Book Finder Admin"
admin.site.site_title = "Book Finder Area"
admin.site.index_title = "Welcome to Book Finder Admin"

app = apps.get_app_config('books')
admin.site.register(app.get_models())

