from django.urls import path
from . import views

app_name = 'books'

urlpatterns = [
	path('',views.index,name = 'index'),
	path('<int:bookreq>',views.details,name='details'),
	path('search/',views.overview,name = 'search'),
	path('search/<str:bookreq>',views.index2,name='index2' ),
	path('addbook/',views.addbook,name='addbook'),
	#path('<str:delreq>/<str:option>/deletebook',views.deletebook,name='deletebook'),
]	
