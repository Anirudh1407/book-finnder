from django import forms
from crispy_forms.helper import FormHelper
from django.urls import reverse
from crispy_forms.bootstrap import Field, InlineRadios, TabHolder, Tab
from crispy_forms.layout import Submit

class SearchForm(forms.Form):
    search = forms.CharField(label = 'search' ,max_length=200)


class AddBook(forms.Form):
	book_name = forms.CharField(label = 'Title',max_length = 200, required= True)
	book_author = forms.CharField(label = 'Authors',max_length = 20, required= True)
	book_edition = forms.IntegerField(label = 'Edition', required = True)
	book_link = forms.CharField(label = 'Link',max_length = 200, required = True)
	book_tags = forms.CharField(label = 'Tags',max_length = 20, required = False)
	def __init__(self, *args, **kwargs):
		super(AddBook, self).__init__(*args, **kwargs)
		self.helper = FormHelper()
		self.helper.form_method = 'post'
		self.helper.form_action = reverse('addbook')
		self.helper.add_input(Submit('submit', 'OK', css_class='btn-dark'))  

class AddIssue(forms.Form):
	description = forms.CharField(label='Description',max_length = 200)




