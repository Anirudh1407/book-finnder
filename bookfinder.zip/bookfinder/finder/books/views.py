from django.shortcuts import render,redirect
from .models import *
from django.contrib.auth.models import User,Group
import random
from django.contrib.auth.decorators import login_required
from .forms import SearchForm,AddBook
from django import forms
import re
import difflib
from difflib import get_close_matches
from admins import models as adminmod
from issues import models as issuemod
from users import models as usermod

# Create your views here.


def details(request,bookreq):
	try:
		bookfiltered = Book.objects.all().get(pk=bookreq)
		authorsfiltered = Author.objects.all().filter(book_id=bookreq)
		tagsfiltered = Tag.objects.all().filter(book_id = bookreq)
		issuesfiltered = issuemod.Issue.objects.all().filter(book_id = bookreq)
	except Book.DoesNotExist:
		return render(request,"users/oops.html",{'reason':"The book no longer exists"})
	return render(request,'books/details.html',{'bookfil':bookfiltered,'authorsfil':authorsfiltered,'tagsfil':tagsfiltered,'issuesfil':issuesfiltered})

def index(request):
	form = SearchForm()
	book_list = Book.objects.all()
	return render(request,'books/index.html',{"book_list":book_list,"form":form})

def overview(request):
    if request.method == 'GET':
        form = SearchForm(request.GET)
        if form.is_valid():
            bookreq = form.cleaned_data["search"]
            url = '/books/search/'+form.cleaned_data["search"]
            return redirect(url)
        else:
            form = SearchForm()
        return render(request,"books/index.html",{'book_list':book_list, 'form':form})


def index2(request,bookreq):
	form = SearchForm()
	print(bookreq)
	val = re.findall(r"\[([A-Za-z0-9_,]+)\]",bookreq)	
	print(val)
	if len(val)>0:
		bookids = []
		booktags = []
		book_list = []
		if len(val)>1:
			for eachval in val:					
				booktags.append(Tag.objects.all().filter(tag__contains=eachval))
			for eachtag in booktags:
				for eachbook in eachtag:
					book_list.append(Book.objects.all().get(pk=eachbook.book_id))
			booklist = list(dict.fromkeys(book_list))
		else:
			vals = val[0].split(",")
			for eachval in vals:					
				booktags.append(Tag.objects.all().filter(tag__contains=eachval))
			for eachbook in booktags[0]:			
				book_list.append(Book.objects.all().get(pk=eachbook.book_id))
			
			for eachtag in booktags:
				booklist = []
				for eachbook in eachtag:					
					booklist.append(Book.objects.all().get(pk=eachbook.book_id))
				print(booklist)
				book_list = list(set(booklist) & set(book_list))
				print(book_list)
					
		
		return render(request,'books/index2.html',{"book_list":book_list, 'form':form})
	else:
		Booklist = Book.objects.all()
		booklist = []
		for book in Booklist :
			booklist.append(book.name)
		bookList = get_close_matches(bookreq,booklist,5,0.5)
		book_list = []
		for eachbook in bookList:
			book_list.append(Book.objects.all().get(name=eachbook)) 
		return render(request,'books/index2.html',{"book_list":book_list, 'form':form})


@login_required
def addbook(request):
	if request.method=="POST":
		form = AddBook(request.POST)
		if form.is_valid():
			book_name = form.cleaned_data['book_name']
			book_author = form.cleaned_data['book_author']
			book_link = form.cleaned_data['book_link']
			linkcount = Book.objects.all().filter(link=book_link)
			if linkcount.count()>0:
				return render(request,'books/bookpresent.html',{"book_list":linkcount})
			book_tags = form.cleaned_data['book_tags']
			book_edition = form.cleaned_data['book_edition']
			book=Book(link=book_link,name=book_name,added_by_id=request.user.id,edition=book_edition)
			book.save()
			bookid = Book.objects.all().get(link=book_link).book
			if "," in book_tags :
				booktag= book_tags.split(",")
				for eachtag in booktag :
					tags=Tag(book = book, tag=eachtag)
					tags.save()			
			else:			
				tags=Tag(book = book, tag=book_tags)
				tags.save()	
			if "," in book_author :
				bookauthor = book_author.split(",")
				for eachauthor in bookauthor :
					author=Author(book = book,author=eachauthor)
					author.save()
			else:
				author=Author(book = book,author=book_author)
				author.save()
			
			bookfiltered = Book.objects.all().get(link=book_link)
			authorsfiltered = Author.objects.all().filter(book_id=bookid)
			tagsfiltered = Tag.objects.all().filter(book_id = bookid)		
			return render(request,'books/bookadded.html',{ 'bookfil':bookfiltered, 'authorsfil':authorsfiltered, 'tagsfil':tagsfiltered})
		else:
			form = AddBook()
			return render(request,"books/addbook.html",{"form":form})
	else:
		form = AddBook()
	return render(request,"books/addbook.html",{"form":form})
	


def start(request):
	return render(request,'index.html')



'''
def deletebook(request, delreq, option):
	if deletereq.time == 1 :
		checkingid = DeleteBookRequest.objects.all().get(pk=delreq).assigned_admin_id
	else:
		checkingid = adminmod.AdminParent(pk=bookmod.DeleteBookRequest.objects.all().get(pk=delreq).assigned_admin_id).creator_id
	if request.user.id==checkingid:
		deletereq= DeleteBookRequest.objects.all().get(pk=delreq)
		bookid=deletereq.book_id
		if deletereq.time == 1 :
			if option == "delete" :
		 		userparent = adminmod.AdminParent.objects.all().get(created_id=userreq)
		 		userparentid=userparent.creator_id
		 		deleteReq=DeleteBookRequest(id=delreq,time=2,assigned_admin_id=userparentid,book_id=bookid)
		 		deleteReq.save()
		 	elif option == "cancel" :
		 		deletereq.delete()
		 
		elif deletereq.time == 2:
			if option == "delete" :
			 	bookdel=bookmod.Book.objects.all().get(book=book_id)
			 	bookdel.delete()
		 	
			elif option == "cancel" :
			 	deletereq.delete()
		return render(request,"books/deletebook.html",{'option' : option})
	return render(request,"users/oops.html",{"reason":"You are not authorized to perform this action"})
	
'''
		


	

