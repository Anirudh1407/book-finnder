from django.db import models
from django.contrib.auth.models import User
from books import models as bookmod
from issues import models as issuemod

# Create your models here.

class UserProfile(models.Model):
	user = models.OneToOneField(User,on_delete=models.CASCADE,primary_key = True)
	creation_date = models.DateTimeField('creation_date')
	gender = models.CharField(max_length = 1)
	name = models.CharField(max_length = 20)
	dob = models.DateTimeField('date_of_birth')
	country = models.CharField(max_length = 20)
	email = models.EmailField(default="google.com")


class ReportedUser(models.Model):
	user = models.ForeignKey(User,on_delete=models.CASCADE)
	reporting_admin = models.ForeignKey(User,on_delete=models.CASCADE,related_name='reporting_admin+')
	reason = models.TextField()
	comment = models.TextField()
	issue = models.ForeignKey(issuemod.Issue,on_delete=models.CASCADE,related_name='issue+')


class BannedUser(models.Model):
	user = models.OneToOneField(User,on_delete=models.CASCADE,primary_key = True)
	reason = models.TextField()
	time = models.IntegerField(default = 0)





