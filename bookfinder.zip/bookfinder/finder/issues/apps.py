from django.apps import AppConfig


class IssuesConfig(AppConfig):
    name = 'issues'
